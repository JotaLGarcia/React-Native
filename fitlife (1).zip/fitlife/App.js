import React from 'react';
import Home from './src/views/home';

export default function(){
    return <Home/>
}

import {View, Text} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react';

const ViewBoxesWithColorAndText = () => {
  return (
    <SafeAreaProvider>
      <SafeAreaView style={{height: 100, flexDirection: 'row'}}>
        <View style={{backgroundColor: 'blue', flex: 0.2}} />
        <View style={{backgroundColor: 'red', flex: 0.4}} />
        <Text>Hello World!</Text>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};