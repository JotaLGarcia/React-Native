import React from 'react';
import { View, Text, Button, StyleSheet, Image} from 'react-native';

export default function Home() {
  return (
    <View style={styles.container}>

      <Text style={styles.title}>Black Skull</Text>
        <Image source={{uri: 'https://m.media-amazon.com/images/I/61HGS0lX3AL._AC_UF350,350_QL80_.jpg'}}
       style={{width: 400, height: 400}} />
      <Text style={styles.subtitle}>Bem-vindo a nossa loja</Text>
      <Button title="Entrar" onPress={() => {}} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    marginBottom: 20,
  },
});